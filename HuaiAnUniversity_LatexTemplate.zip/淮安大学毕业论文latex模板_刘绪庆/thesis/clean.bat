del *.aux /s
del *.bak /s
del *.log /s
del *.bbl /s
del *.dvi /s
del *.blg /s
del *.thm /s
del *.toc /s
del *.out /s
del *.synctex.gz /s
del *.bib~ /s
del *.lof /s
del *.lot /s
del *.synctex /s
del *.spl /s
del *.nav /s
del *.snm /s
:: del main*.pdf /s
